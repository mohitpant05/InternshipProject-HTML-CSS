function showBox(title, image, para , link){
    document.write(`
        <div class='box'>
            <img src=${image} alt=""/>
            
            <h1>
                ${title}
            </h1>j
        </div>
        `
    )
}