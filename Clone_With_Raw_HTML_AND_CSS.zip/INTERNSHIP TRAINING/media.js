function play(){
    document.getElementById('res').innerHTML=`<video src="Top 30 Hindi Nursery Rhymes For Kids _ Hindi Kavita _ Little Treehouse India _ Top Hindi Poems.mp4" controls width="100%"></video>`
}

function play1(){
    document.getElementById('res').innerHTML=`<video src="Top 25 Hindi Rhymes for Children Infobells.mp4" controls width="100%"></video>`
}