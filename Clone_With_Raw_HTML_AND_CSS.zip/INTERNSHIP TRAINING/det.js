let std=new Object();
std.sid=123;
std.name="Sham";
std.city="Ldh";
std.h=34;
std.e=78;
std.m=45;
std.s=78;
std.c=5;


intin=[12,3,4,3,4,2,55,2,23,3]

for(x of intin){

    document.write(`<li style="list-style-type:none">${x}</li>`)
}

document.write(
    `
    <li>${std.sid}</li>
    <li>${std.name}</li>
    <li>${std.city}</li>
    <li>${std.h}</li>
    <li>${std.e}</li>
    <li>${std.m}</li>
    <li>${std.s}</li>
    <li>${std.c}</li>
    `
)



let showDet=function(){
    return(`<tr style="text-align:center">
        <td>${std.sid}</td>
        <td>${std.name}</td>
        <td>${std.city}</td>
        <td>${std.h}</td>
        <td>${std.e}</td>
        <td>${std.m}</td>
        <td>${std.s}</td>
        <td>${std.c}</td>
        </tr>
    `
)}

document.write(`<table border='1' width="50%">
<tr style="text-align:center">
        <th>SID</th>
        <th>Name</th>
        <th>City</th>
        <th>Hindi</th>
        <th>Eng</th>
        <th>Math</th>
        <th>Sci</th>
        <th>Comp</th>
        </tr>

`)
document.write(showDet())

document.write(`</table>`)


document.write(``)


let emp_data=new Object();
emp_data.id=134;
emp_data.name="raman";
emp_data.address={
    city:"Delhi",
    pin:123421
}

document.write(`
<p> Welcome ${emp_data.name} your id is ${emp_data.id} and your current address is ${emp_data.address.city} with pin is ${emp_data.address.pin}</p>`)